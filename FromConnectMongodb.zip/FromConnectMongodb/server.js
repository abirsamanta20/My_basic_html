const express = require("express");
const mongoose = require("mongoose");
const path = require("path");

const port = 3010;
const app = express();

// Middleware to serve static files and parse form data
app.use(express.static(__dirname));
app.use(express.urlencoded({ extended: true }));

// MongoDB connection
mongoose.connect("mongodb://127.0.0.1:27017/employee");
const db = mongoose.connection;
db.once("open", () => {
  console.log("MongoDB connection successful...");
});

// Mongoose schema and model
const userSchema = new mongoose.Schema({
  reg_no: String,
  f_name: String,
  l_name: String,
  email: String,
  designation: String,
});

const Users = mongoose.model("emp_details", userSchema);

// Route to load the HTML form
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "form.html"));
});

// Route to serve success page (optional direct link)
app.get("/success", (req, res) => {
  res.sendFile(path.join(__dirname, "success.html"));
});

// Handle form POST submission
app.post("/post", async (req, res) => {
  console.log("Received POST:", req.body);
  try {
    const { reg_no, f_name, l_name, email, designation } = req.body;

    const user = new Users({
      reg_no,
      f_name,
      l_name,
      email,
      designation,
    });

    await user.save();
    console.log(user);

    // Redirect or serve the success page
    res.sendFile(path.join(__dirname, "success.html"));
  } catch (error) {
    console.error("Error saving user:", error);
    res.status(500).send("Server Error");
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server started at http://localhost:${port}`);
});
